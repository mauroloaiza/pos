java -cp ./lib/derbynet.jar org.apache.derby.drda.NetworkServerControl start -h 0.0.0.0 -p 51527


